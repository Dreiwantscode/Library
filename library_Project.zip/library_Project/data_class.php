<?php
include("db.php");

class data extends db {
    private $bookpic;
    private $bookname;
    private $bookdetail;
    private $bookaudor;
    private $bookpub;
    private $branch;
    private $bookprice;
    private $bookquantity;
    private $type;

    private $book;
    private $userselect;
    private $days;
    private $getdate;
    private $returnDate;

    function __construct() {
        parent::__construct();
        if ($this->connection === null || $this->connection->errorCode() !== '00000') {
            $errorInfo = $this->connection->errorInfo();
            $errorMessage = isset($errorInfo[2]) ? $errorInfo[2] : "Unknown error occurred.";
            $errorDetails = print_r($errorInfo, true);
            die("Database connection error: " . $errorMessage . "<br>Error details: " . $errorDetails);
        }
    }
    
    function addnewuser($name, $pasword, $email, $type) {
        $this->name = $name;
        $this->pasword = $pasword;
        $this->email = $email;
        $this->type = $type;

        $q = "INSERT INTO userdata (id, name, email, pass, type) VALUES (NULL, :name, :email, :pasword, :type)";

        $stmt = $this->connection->prepare($q);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':pasword', $pasword);
        $stmt->bindParam(':type', $type);

        if ($stmt->execute()) {
            header("Location:admin_service_dashboard.php?msg=New Add done");
        } else {
            header("Location:admin_service_dashboard.php?msg=Register Fail");
        }
    }

    function userLogin($t1, $t2) {
        $q = "SELECT * FROM userdata WHERE email = :email AND pass = :password";
        $stmt = $this->connection->prepare($q);
        $stmt->bindParam(':email', $t1);
        $stmt->bindParam(':password', $t2);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            foreach ($stmt->fetchAll() as $row) {
                $logid = $row['id'];
                header("Location: otheruser_dashboard.php?userlogid=$logid");
            }
        } else {
            header("Location: index.php?msg=Invalid Credentials");
        }
    }

    function adminLogin($t1, $t2) {
        $q = "SELECT * FROM admin WHERE email = :email AND pass = :password";
        $stmt = $this->connection->prepare($q);
        $stmt->bindParam(':email', $t1);
        $stmt->bindParam(':password', $t2);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            foreach ($stmt->fetchAll() as $row) {
                $logid = $row['id'];
                header("Location: admin_service_dashboard.php?logid=$logid");
            }
        } else {
            header("Location: index.php?msg=Invalid Credentials");
        }
    }

    function addbook($bookpic, $bookname, $bookdetail, $bookaudor, $bookpub, $branch, $bookprice, $bookquantity) {
        $this->bookpic = $bookpic;
        $this->bookname = $bookname;
        $this->bookdetail = $bookdetail;
        $this->bookaudor = $bookaudor;
        $this->bookpub = $bookpub;
        $this->branch = $branch;
        $this->bookprice = $bookprice;
        $this->bookquantity = $bookquantity;

        $q = "INSERT INTO book (id, bookpic, bookname, bookdetail, bookaudor, bookpub, branch, bookprice, bookquantity, bookava, bookrent) 
              VALUES (NULL, :bookpic, :bookname, :bookdetail, :bookaudor, :bookpub, :branch, :bookprice, :bookquantity, :bookquantity, 0)";

        $stmt = $this->connection->prepare($q);
        $stmt->bindParam(':bookpic', $bookpic);
        $stmt->bindParam(':bookname', $bookname);
        $stmt->bindParam(':bookdetail', $bookdetail);
        $stmt->bindParam(':bookaudor', $bookaudor);
        $stmt->bindParam(':bookpub', $bookpub);
        $stmt->bindParam(':branch', $branch);
        $stmt->bindParam(':bookprice', $bookprice);
        $stmt->bindParam(':bookquantity', $bookquantity);

        if ($stmt->execute()) {
            header("Location:admin_service_dashboard.php?msg=done");
        } else {
            header("Location:admin_service_dashboard.php?msg=fail");
        }
    }

    function getissuebook($userloginid) {
        $newfine = "";
        $issuereturn = "";

        $q = "SELECT * FROM issuebook WHERE userid = :userid";
        $stmt = $this->connection->prepare($q);
        $stmt->bindParam(':userid', $userloginid);
        $stmt->execute();

        foreach ($stmt->fetchAll() as $row) {
            $issuereturn = $row['issuereturn'];
            $fine = $row['fine'];
            $newfine = $fine;
        }

        $getdate = date("d/m/Y");
        if ($issuereturn < $getdate) {
            $q = "UPDATE issuebook SET fine = :fine WHERE userid = :userid";
            $stmt = $this->connection->prepare($q);
            $stmt->bindParam(':fine', $newfine);
            $stmt->bindParam(':userid', $userloginid);

            if ($stmt->execute()) {
                $q = "SELECT * FROM issuebook WHERE userid = :userid";
                $stmt = $this->connection->prepare($q);
                $stmt->bindParam(':userid', $userloginid);
                $stmt->execute();
                return $stmt->fetchAll();
            } else {
                $q = "SELECT * FROM issuebook WHERE userid = :userid";
                $stmt = $this->connection->prepare($q);
                $stmt->bindParam(':userid', $userloginid);
                $stmt->execute();
                return $stmt->fetchAll();
            }
        } else {
            $q = "SELECT * FROM issuebook WHERE userid = :userid";
            $stmt = $this->connection->prepare($q);
            $stmt->bindParam(':userid', $userloginid);
            $stmt->execute();
            return $stmt->fetchAll();
        }
    }

    function getbook() {
        $q = "SELECT * FROM book";
        $stmt = $this->connection->query($q);
        return $stmt->fetchAll();
    }

    function getbookissue() {
        $q = "SELECT * FROM book WHERE bookava != 0";
        $stmt = $this->connection->query($q);
        return $stmt->fetchAll();
    }

    function userdata() {
        $q = "SELECT * FROM userdata";
        $stmt = $this->connection->query($q);
        return $stmt->fetchAll();
    }

    function getbookdetail($id) {
        $q = "SELECT * FROM book WHERE id = :id";
        $stmt = $this->connection->prepare($q);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    function userdetail($id) {
        $q = "SELECT * FROM userdata WHERE id = :id";
        $stmt = $this->connection->prepare($q);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    function requestbook($userid, $bookid) {
        $q = "SELECT * FROM book WHERE id = :bookid";
        $stmt = $this->connection->prepare($q);
        $stmt->bindParam(':bookid', $bookid);
        $stmt->execute();
        $book = $stmt->fetch();

        $q = "SELECT * FROM userdata WHERE id = :userid";
        $stmt = $this->connection->prepare($q);
        $stmt->bindParam(':userid', $userid);
        $stmt->execute();
        $user = $stmt->fetch();

        $username = $user['name'];
        $usertype = $user['type'];
        $bookname = $book['bookname'];

        $days = ($usertype == "student") ? 7 : 21;

        $q = "INSERT INTO requestbook (id, userid, bookid, username, usertype, bookname, issuedays) VALUES (NULL, :userid, :bookid, :username, :usertype, :bookname, :days)";
        $stmt = $this->connection->prepare($q);
        $stmt->bindParam(':userid', $userid);
        $stmt->bindParam(':bookid', $bookid);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':usertype', $usertype);
        $stmt->bindParam(':bookname', $bookname);
        $stmt->bindParam(':days', $days);

        if ($stmt->execute()) {
            header("Location:otheruser_dashboard.php?msg=done");
        } else {
            header("Location:otheruser_dashboard.php?msg=fail");
        }
    }

    function deleteuserdata($id) {
        $q = "DELETE FROM userdata WHERE id = :id";
        $stmt = $this->connection->prepare($q);
        $stmt->bindParam(':id', $id);

        if ($stmt->execute()) {
            header("Location:admin_service_dashboard.php?msg=done");
        } else {
            header("Location:admin_service_dashboard.php?msg=fail");
        }
    }

    function deletebook($id) {
        $q = "DELETE FROM book WHERE id = :id";
        $stmt = $this->connection->prepare($q);
        $stmt->bindParam(':id', $id);

        if ($stmt->execute()) {
            header("Location:admin_service_dashboard.php?msg=done");
        } else {
            header("Location:admin_service_dashboard.php?msg=fail");
        }
    }

    function issuereport() {
        $q = "SELECT * FROM issuebook";
        $stmt = $this->connection->query($q);
        return $stmt->fetchAll();
    }

    function requestbookdata() {
        $q = "SELECT * FROM requestbook";
        $stmt = $this->connection->query($q);
        return $stmt->fetchAll();
    }

    function issuebookapprove($book, $userselect, $days, $getdate, $returnDate, $redid) {
        $this->book = $book;
        $this->userselect = $userselect;
        $this->days = $days;
        $this->getdate = $getdate;
        $this->returnDate = $returnDate;

        $q = "SELECT * FROM book WHERE bookname = :bookname";
        $stmt = $this->connection->prepare($q);
        $stmt->bindParam(':bookname', $book);
        $stmt->execute();
        $recordSetss = $stmt->fetchAll();

        $q = "SELECT * FROM userdata WHERE name = :name";
        $stmt = $this->connection->prepare($q);
        $stmt->bindParam(':name', $userselect);
        $stmt->execute();
        $recordSet = $stmt->fetchAll();

        if (count($recordSet) > 0) {
            foreach ($recordSet as $row) {
                $issueid = $row['id'];
                $issuetype = $row['type'];
            }
            foreach ($recordSetss as $row) {
                $bookid = $row['id'];
                $bookname = $row['bookname'];

                $newbookava = $row['bookava'] - 1;
                $newbookrent = $row['bookrent'] + 1;
            }

            $q = "UPDATE book SET bookava = :bookava, bookrent = :bookrent WHERE id = :id";
            $stmt = $this->connection->prepare($q);
            $stmt->bindParam(':bookava', $newbookava);
            $stmt->bindParam(':bookrent', $newbookrent);
            $stmt->bindParam(':id', $bookid);

            if ($stmt->execute()) {
                $q = "INSERT INTO issuebook (userid, issuename, issuebook, issuetype, issuedays, issuedate, issuereturn, fine) 
                      VALUES (:userid, :issuename, :issuebook, :issuetype, :issuedays, :issuedate, :issuereturn, 0)";
                $stmt = $this->connection->prepare($q);
                $stmt->bindParam(':userid', $issueid);
                $stmt->bindParam(':issuename', $userselect);
                $stmt->bindParam(':issuebook', $book);
                $stmt->bindParam(':issuetype', $issuetype);
                $stmt->bindParam(':issuedays', $days);
                $stmt->bindParam(':issuedate', $getdate);
                $stmt->bindParam(':issuereturn', $returnDate);

                if ($stmt->execute()) {
                    $q = "DELETE FROM requestbook WHERE id = :id";
                    $stmt = $this->connection->prepare($q);
                    $stmt->bindParam(':id', $redid);
                    $stmt->execute();

                    header("Location:admin_service_dashboard.php?msg=done");
                } else {
                    header("Location:admin_service_dashboard.php?msg=fail");
                }
            } else {
                header("Location:admin_service_dashboard.php?msg=fail");
            }
        } else {
            header("location: index.php?msg=Invalid Credentials");
        }
    }

    function issuebook($book, $userselect, $days, $getdate, $returnDate) {
        $this->book = $book;
        $this->userselect = $userselect;
        $this->days = $days;
        $this->getdate = $getdate;
        $this->returnDate = $returnDate;

        $q = "SELECT * FROM book WHERE bookname = :bookname";
        $stmt = $this->connection->prepare($q);
        $stmt->bindParam(':bookname', $book);
        $stmt->execute();
        $recordSetss = $stmt->fetchAll();

        $q = "SELECT * FROM userdata WHERE name = :name";
        $stmt = $this->connection->prepare($q);
        $stmt->bindParam(':name', $userselect);
        $stmt->execute();
        $recordSet = $stmt->fetchAll();

        if (count($recordSet) > 0) {
            foreach ($recordSet as $row) {
                $issueid = $row['id'];
                $issuetype = $row['type'];
            }
            foreach ($recordSetss as $row) {
                $bookid = $row['id'];
                $bookname = $row['bookname'];

                $newbookava = $row['bookava'] - 1;
                $newbookrent = $row['bookrent'] + 1;
            }

            $q = "UPDATE book SET bookava = :bookava, bookrent = :bookrent WHERE id = :id";
            $stmt = $this->connection->prepare($q);
            $stmt->bindParam(':bookava', $newbookava);
            $stmt->bindParam(':bookrent', $newbookrent);
            $stmt->bindParam(':id', $bookid);

            if ($stmt->execute()) {
                $q = "INSERT INTO issuebook (userid, issuename, issuebook, issuetype, issuedays, issuedate, issuereturn, fine) 
                      VALUES (:userid, :issuename, :issuebook, :issuetype, :issuedays, :issuedate, :issuereturn, 0)";
                $stmt = $this->connection->prepare($q);
                $stmt->bindParam(':userid', $issueid);
                $stmt->bindParam(':issuename', $userselect);
                $stmt->bindParam(':issuebook', $book);
                $stmt->bindParam(':issuetype', $issuetype);
                $stmt->bindParam(':issuedays', $days);
                $stmt->bindParam(':issuedate', $getdate);
                $stmt->bindParam(':issuereturn', $returnDate);

                if ($stmt->execute()) {
                    header("Location:admin_service_dashboard.php?msg=done");
                } else {
                    header("Location:admin_service_dashboard.php?msg=fail");
                }
            } else {
                header("Location:admin_service_dashboard.php?msg=fail");
            }
        } else {
            header("location: index.php?msg=Invalid Credentials");
        }
    }
}
?>
